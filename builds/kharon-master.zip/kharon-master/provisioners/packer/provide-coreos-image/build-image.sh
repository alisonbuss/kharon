#!/bin/bash

#-----------------------|DOCUMENTATION|-----------------------#
# @descr: Script de inicialização de execução do projeto no terraform     
# @fonts:  
# @example: 
#    
#-------------------------------------------------------------#

function startBuilding {

} 

#startBuilding "$@";

exit 0;